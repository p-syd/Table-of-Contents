from __future__ import unicode_literals
import json
import requests
import pandas as pd
from flask import Flask, request, Response, render_template, session, redirect, url_for

app = Flask(__name__)

@app.route('/',methods=['GET', 'POST'])
def scrape():
	if request.method == 'GET':
	    return render_template('index1.html', value='hi')	
	if request.method == 'POST':
	    limk=request.form["link"]
	    #ThespiderSpider.urlneed(limk)
	    params = { 'spider_name': 'books','start_requests': True,'url' : limk }
	    response = requests.get('http://localhost:9080/crawl.json', params)
	    data = json.loads(response.text)
	    df=pd.DataFrame(data=data['items'], columns=['TITLE','LINK','SUBTITLE'])
	    df=df.fillna(value=' ')
	    return render_template("simple.html", column_names=df.columns.values, row_data=list(df.values.tolist()),link_column="LINK", zip=zip)
       
if __name__ == '__main__':
    app.run(debug=True, port=1234)

'''
        return render_template('simple.html',  tables=[df.to_html(classes='data',  index=False)], titles=df.columns.values)
'''
