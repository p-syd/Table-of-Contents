from __future__ import unicode_literals
import scrapy

class ThespiderSpider(scrapy.Spider):
	name = 'books'

	def parse (self,response):
		#limk=response.xpath('//div[@class= "wy-menu wy-menu-vertical"]/descendant::a/@href').getall()
		c=0
		
		sstitle=response.xpath('//a[@class= "current reference internal"]/text()').getall() 
		
		title1=response.xpath('//li[@class="toctree-l1" and 3]/a[@class="reference internal" and 1]/text()').getall()    
		title=map(lambda x:x.strip(),title1)
		l=1	
		
		title=response.xpath('//*[@class="current"] /descendant::text()').getall()
		
		for i in title :
			
			if i !='\n' and i not in title1:
					c+=1
					if i in sstitle :
						yield {
						'TITLE' :i.upper(),
						'LINK' : response.url
						}
						
					
					else :
						yield {
						'SUBTITLE' :i
						}
						l+=1
			

		next_page = response.css('div.rst-footer-buttons a::attr(href)').get()
		if next_page is not None:
			yield scrapy.Request(response.urljoin(next_page), callback=self.parse)
              
